(function (angular) {
    // 创建首页模块
    var app = angular.module('personalinfo.vocational_skills', ['ngRoute']);
    // 路由配置
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        //解决hash值乱码
        $locationProvider.hashPrefix("");
        $routeProvider.when('/vocational_skills', {
            templateUrl: './vocational_skills/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'vocational_skills_listController'
        })
    }]);


    app.controller('vocational_skills_listController', [
        '$scope', '$http',
        function ($scope, $http) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));
            //注册初始化页面时间
            $scope.initList = function () {
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/show_vocational_skills/vocational_skills'
                })
                    .then(function success(res) {
                        $scope.list = res.data;
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                $scope.mark = new MarkBox(600, 400, '添加个人信息', form[0]);
                $scope.mark.init();
                // 清空表单
                $scope.positions = "";
                $scope.compensation = "";
                $scope.workplace = "";
                $scope.jobnature = "";
                $scope.currentstate = "";
                //表单提交事件
                form.find("input").eq(9).unbind("click").on("click", $scope.subAfterWrite);
            };
            //注册提交事件的方法
            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_vocational_skills/vocational_skills',
                    data: {
                        name: $scope.positions,
                        age: $scope.compensation,
                        experience: $scope.workplace,
                        email: $scope.jobnature,
                        phone: $scope.currentstate
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //关闭弹窗
                        $scope.mark.close();
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };
            //注册删除事件
            $scope.deleteALine = function (id) {
                $http({
                    method: 'delete',
                    url: 'http://localhost:3000/delete_job_intension/job_intension/' + id
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.initList();
                    }
                });
            };
            //注册修改事件
            $scope.editInfo = function (id) {
                // 先根据数据id查询最新的数据
                console.log(id);
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_vocational_skills/vocational_skills/' + id
                }).then(function success(res) {
                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.index = res.data.index;
                    $scope.description = res.data.description;
                    console.log(form.find("input").eq(3));
                    form.find("input").eq(3).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    var lists =[];
                    lists.push($scope.description);
                    console.log(lists);
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_vocational_skills/vocational_skills',
                        data: {
                            //index: $scope.index,
                            lists: lists
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        console.log(res)
                        if (res.data.flag == '1') {
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });

                }
            }
        }]);
})(angular);

