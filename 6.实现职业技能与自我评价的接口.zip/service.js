
//设置获取数据的方法
const db = require('./db.js');

exports.showData = (req,res) => {
    let sql = 'select * from '+ req.params.mysql;
    db.base(sql,null,(result)=>{
        res.json(result);
    });
};


exports.addData = (req,res) => {
    let data = req.body;
    let sql = 'insert into '+req.params.mysql+' set ?';
    db.base(sql,data,(result)=>{
        if(result.affectedRows == 1){
            res.json({flag : 1});
        }else{
            res.json({flag : 2});
        }  
    });
};
exports.getDataById = (req,res) => {
    let id = req.params.id;
    let sql = 'select * from '+req.params.mysql+' where id=?'
    let data = [id];
    db.base(sql,data,(result)=>{
        res.json(result[0]);
    })
};

exports.editData = (req,res) => {
    let info = req.body;
    let str = "";
    let aftStr = "";
    let dataArr = [];
    let aftDataArr = [];
    for(let key in info){
        if(key == "id"){
            aftStr = 'where '+key+'=?';
            aftDataArr.push(info[key]);
        }else{
            str += key+"=?," ;
            dataArr.push(info[key]);
        }
    };
    str = str.substring(0,str.length-1) + " " + aftStr;
    // let sql = 'update personal_info set name=?,age=?,experience=?,email=?,phone=?,website=?,address=? where id=?';
    let sql = 'update '+req.params.mysql+' set ' + str;
    // let data = [info.name,info.age,info.experience,info.email,info.phone,info.website,info.address,info.id];
    dataArr.push.apply(dataArr,aftDataArr);
    let data = dataArr;
    
    db.base(sql,data,(result)=>{
        if(result.affectedRows == 1){
            res.json({flag : 1});
        }else{
            res.json({flag : 2});
        }  
    });
};
exports.deleteDataById = (req,res) => {
    let id = req.params.id;
    let sql = 'delete from '+req.params.mysql+' where id=?';
    let data = [id];    
    db.base(sql,data,(result)=>{
        if(result.affectedRows == 1){
            res.json({flag : 1});
        }else{
            res.json({flag : 2});
        }  
    });
};
