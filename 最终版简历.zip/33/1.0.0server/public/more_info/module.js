
(function (angular) {
    // 创建首页模块
    var app = angular.module('personalinfo.more_info', ['ngRoute']);
    // 路由配置
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix("");
        $routeProvider.when('/more_info/:id', {
            templateUrl: './more_info/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'more_info_listController'
        })
        .when('/more_info/:id/job_intension', {
            templateUrl: './job_intension/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'job_intension_listController'
        })
        .when('/more_info/:id/vocational_skills', {
            templateUrl: './vocational_skills/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'vocational_skills_listController'
        })
        .when('/more_info/:id/occupational_history', {
            templateUrl: './occupational_history/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'occupational_history_listController'
        })
        .when('/more_info/:id/project_experience', {
            templateUrl: './project_experience/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'project_experience_listController'
        })
        .when('/more_info/:id/self_assessment', {
            templateUrl: './self_assessment/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'self_assessment_listController'
        })
        .when('/more_info/:id/contact_me', {
            templateUrl: './contact_me/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'contact_me_listController'
        })
    }])


    app.controller('job_intension_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/job_intension/' + $scope.getId
                })
                    .then(function success(res) {

                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        
                        $scope.dataList = $scope.todoss;
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.positions = "";
                $scope.compensation = "";
                $scope.workplace = "";
                $scope.jobnature = "";
                $scope.currentstate = "";
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            id : $scope.getId || '未填写',
                            positions: $scope.positions || '未填写',
                            compensation: $scope.compensation || '未填写',
                            workplace: $scope.workplace || '未填写',
                            jobnature: $scope.jobnature || '未填写',
                            currentstate: $scope.currentstate || '未填写'
                        }
                $scope.dataList.push($scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/job_intension',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    positions: $scope.positions || '未填写',
                                    compensation: $scope.compensation || '未填写',
                                    workplace: $scope.workplace || '未填写',
                                    jobnature: $scope.jobnature || '未填写',
                                    currentstate: $scope.currentstate || '未填写'
                                }];
                $http({
                    method: 'post',
                    url: apiadmin + '/add_info_list/job_intension',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: apiadmin + '/get_info_list/job_intension/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/job_intension',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }
            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.positions = $scope.dataList[num].positions;
                $scope.compensation = $scope.dataList[num].compensation;
                $scope.workplace = $scope.dataList[num].workplace;
                $scope.jobnature = $scope.dataList[num].jobnature;
                $scope.currentstate = $scope.dataList[num].currentstate;
                btn.unbind("click").on("click",$scope.subAfterChange);
            }

            $scope.subAfterChange = function () {

                $scope.next = {
                            "id":$scope.id,
                            "positions": $scope.positions || "未填写",
                            "compensation": $scope.compensation || "未填写",
                            "workplace": $scope.workplace || "未填写",
                            "jobnature": $scope.jobnature || "未填写",
                            "currentstate": $scope.currentstate || "未填写",//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/job_intension',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);

    app.controller('vocational_skills_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/vocational_skills/' + $scope.getId
                })
                    .then(function success(res) {
                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        $scope.dataList = $scope.todoss;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                $scope.description = "";
                $scope.todos = [];
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id":$scope.getId,
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.unshift($scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                                }];
                $http({
                    method: 'post',
                    url: apiadmin + '/add_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: apiadmin + '/get_info_list/vocational_skills/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.todos = [];
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }


                $scope.subAfterEdit = function () {
                    $scope.next = {
                                "id":Math.random(),
                                "description": $scope.todos || [{"id":1,"name":"未填写","completed":false}]//,"$$hashKey":"object:3"
                            };

                    $scope.dataList.unshift($scope.next);
                   $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/vocational_skills',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                            //lists: JSON.stringify($scope.dataList),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/vocational_skills',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }

            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                $scope.num = num;
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.description = $scope.dataList[num].description;
                btn.unbind("click").on("click",$scope.subAfterChange);
                $scope.todos = $scope.description;
            }

            $scope.subAfterChange = function () {
                $scope.next = {
                            "id":$scope.id,
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);

    app.controller('occupational_history_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/occupational_history/' + $scope.getId
                })
                    .then(function success(res) {

                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        
                        $scope.dataList = $scope.todoss;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.time = "";
                $scope.comName = "";
                $scope.section = "";
                $scope.position = "";
                $scope.description = "";
                $scope.todos = [];
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id":$scope.getId,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.push($scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/occupational_history',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "time": $scope.time || "未填写",
                                    "comName": $scope.comName || "未填写",
                                    "section": $scope.section || "未填写",
                                    "position": $scope.position || "未填写",
                                    "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                                }];
                $http({
                    method: 'post',
                    url: apiadmin + '/add_info_list/occupational_history',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: apiadmin + '/get_info_list/occupational_history/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.todos = [];
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                  console.log($scope.todos);
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }


                $scope.subAfterEdit = function () {
                    $scope.next = {
                                "id":Math.random(),
                                "time": $scope.time || "未填写",
                                "comName": $scope.comName || "未填写",
                                "section": $scope.section || "未填写",
                                "position": $scope.position || "未填写",
                                "description": $scope.todos || [{"id":1,"name":"未填写","completed":false}]//,"$$hashKey":"object:3"
                            };

                    $scope.dataList.push($scope.next);
                   $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/occupational_history',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                            //lists: JSON.stringify($scope.dataList),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/occupational_history',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }

            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                $scope.num = num;
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.time = $scope.dataList[num].time;
                $scope.comName = $scope.dataList[num].comName;
                $scope.section = $scope.dataList[num].section;
                $scope.position = $scope.dataList[num].position;
                $scope.description = $scope.dataList[num].description;
                btn.unbind("click").on("click",$scope.subAfterChange);
                $scope.todos = $scope.description;
            }

            $scope.subAfterChange = function () {
                $scope.next = {
                            "id":$scope.id,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/occupational_history',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);
    
    app.controller('project_experience_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/project_experience/' + $scope.getId
                })
                    .then(function success(res) {
                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        $scope.dataList = $scope.todoss;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.time = "";
                $scope.comName = "";
                $scope.section = "";
                $scope.position = "";
                $scope.description = "";
                $scope.todos = [];
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id":$scope.getId,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.unshift($scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/project_experience',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "time": $scope.time || "未填写",
                                    "comName": $scope.comName || "未填写",
                                    "section": $scope.section || "未填写",
                                    "position": $scope.position || "未填写",
                                    "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                                }];
                $http({
                    method: 'post',
                    url: apiadmin + '/add_info_list/project_experience',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: apiadmin + '/get_info_list/project_experience/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.todos = [];
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }


                $scope.subAfterEdit = function () {
                    $scope.next = {
                                "id":Math.random(),
                                "time": $scope.time || "未填写",
                                "comName": $scope.comName || "未填写",
                                "section": $scope.section || "未填写",
                                "position": $scope.position || "未填写",
                                "description": $scope.todos || [{"id":1,"name":"未填写","completed":false}]//,"$$hashKey":"object:3"
                            };

                    $scope.dataList.unshift($scope.next);
                   $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/project_experience',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                            //lists: JSON.stringify($scope.dataList),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/project_experience',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }

            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                $scope.num = num;
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.time = $scope.dataList[num].time;
                $scope.comName = $scope.dataList[num].comName;
                $scope.section = $scope.dataList[num].section;
                $scope.position = $scope.dataList[num].position;
                $scope.description = $scope.dataList[num].description;
                btn.unbind("click").on("click",$scope.subAfterChange);
                $scope.todos = $scope.description;
            }

            $scope.subAfterChange = function () {
                $scope.next = {
                            "id":$scope.id,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/project_experience',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);
    
    app.controller('self_assessment_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/self_assessment/' + $scope.getId
                })
                    .then(function success(res) {
                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        $scope.dataList = $scope.todoss;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                $scope.description = "";
                $scope.todos = [];
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id":$scope.getId,
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.unshift($scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                                }];
                $http({
                    method: 'post',
                    url: apiadmin + '/add_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: apiadmin + '/get_info_list/self_assessment/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.todos = [];
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }


                $scope.subAfterEdit = function () {
                    $scope.next = {
                                "id":Math.random(),
                                "description": $scope.todos || [{"id":1,"name":"未填写","completed":false}]//,"$$hashKey":"object:3"
                            };

                    $scope.dataList.unshift($scope.next);
                   $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/self_assessment',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                            //lists: JSON.stringify($scope.dataList),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: apiadmin + '/edit_info_list/self_assessment',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }

            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                $scope.num = num;
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.description = $scope.dataList[num].description;
                btn.unbind("click").on("click",$scope.subAfterChange);
                $scope.todos = $scope.description;
            }

            $scope.subAfterChange = function () {
                $scope.next = {
                            "id":$scope.id,
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: apiadmin + '/edit_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);
    
    app.controller('contact_me_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: apiadmin + '/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
        }]);


})(angular);

