

var mysql = require('mysql');
exports.base = (sql, data, callback) => {
    var connection = mysql.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: 'Alias@2017',
        database: 'personal_sql'
    });

    connection.connect();

    connection.query(sql, data, function (error, results, fields) {
        if (error) throw error;
        //console.log('The solution is: ', results[0].solution);
        //当返回数据成功是调用回调函数
        callback(results);
    });

    connection.end();
}