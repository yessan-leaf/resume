$(function(){
	$.ajax({
        url: "http://www.yessan.win:3000/get_info_list/personal_info_list/532805195",
        type: "get",
        dateType: "json",
        success: function(data) {
            var personalInfoHtml = '<li><span>姓名</span>: '+data.name+'</li>'
			+'<li><span>年龄</span>: '+data.age+'</li>'
			+'<li><span>工作年限</span>: '+data.experience+'</li>'
			+'<li><span>邮箱</span>: <a href="mailto:"'+data.email+'>'+data.email+'</a></li>'
			+'<li><span>手机号</span>: '+data.phone+'</li>'
			+'<li><span>个人网页</span>: <a href="#">'+data.name+'</a></li>'
			+'<li><span>居住地</span>: '+data.address+'</li>';
            $("#personal_info").html(personalInfoHtml);
        }
    });

	$.ajax({
        url: "http://www.yessan.win:3000/get_info_list/job_intension/532805195",
        type: "get",
        dateType: "json",
        success: function(data) {
        	var value = JSON.parse(data.lists).dataList[0];
            var jobIntension = '<p>期望职位: '+value.positions+'</p>'
							+'<p>期望薪资: '+value.compensation+'</p>'
							+'<p>工作地点: '+value.workplace+'</p>'
							+'<p>工作性质: '+value.jobnature+'</p>'
							+'<p>目前状态: '+value.currentstate+'</p>';
            $(".jobIntension").html(jobIntension);
        }
    });

	$.ajax({
        url: "http://www.yessan.win:3000/get_info_list/vocational_skills/532805195",
        type: "get",
        dateType: "json",
        success: function(data) {
        	data = JSON.parse(data.lists).dataList[0];
        	var menuHtml = template("menu-template", data);
            $(".vocational_skills").html(menuHtml);
        }
    });	


    $.ajax({
        url: "http://www.yessan.win:3000/get_info_list/occupational_history/532805195",
        type: "get",
        dateType: "json",
        success: function(data) {
        	data = JSON.parse(data.lists).dataList[0];
        	var occupationalHistoryOne = '<p>时间：'+data.time+' </p>'
								+'<p>公司：'+data.comName+'</p>'
								+'<p>部门：'+data.section+'</p>'
								+'<p>职位：'+data.position+'</p>'
								+'<p>工作描述:</p>';
			$(".occupational_history_one").html(occupationalHistoryOne);
        	var occupationalHistory = template("occupational_history_template", data);
            $(".occupational_history").html(occupationalHistory);
        }
    });


	$.ajax({
        url: "http://www.yessan.win:3000/get_info_list/self_assessment/532805195",
        type: "get",
        dateType: "json",
        success: function(data) {
        	data = JSON.parse(data.lists).dataList[0];
        	var selfAssessment = template("self_assessment_template", data);
            $(".self_assessment").html(selfAssessment);
        }
    });	

});