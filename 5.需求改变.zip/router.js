

//引入设置路由需要的块

const express = require("express");
const router = express.Router();
const service = require('./service.js');    


// 提供所有的个人信息
router.get('/show_personal_info/:mysql',service.showData);

router.post('/add_personal_info/:mysql',service.addData);

router.get('/get_personal_info/:mysql/:id',service.getDataById);

router.put('/edit_personal_info/:mysql',service.editData);

router.delete('/delete_personal_info/:mysql/:id',service.deleteDataById);


// 求职意向
router.get('/show_job_intension/:mysql',service.showData);

router.post('/add_job_intension/:mysql',service.addData);

router.get('/get_job_intension/:mysql/:id',service.getDataById);

router.put('/edit_job_intension/:mysql',service.editData);

router.delete('/delete_job_intension/:mysql/:id',service.deleteDataById);


// 求职意向
router.get('/show_vocational_skills/:mysql',service.showData);

router.post('/add_vocational_skills/:mysql',service.addData);

router.get('/get_vocational_skills/:mysql/:id',service.getDataById);

router.put('/edit_vocational_skills/:mysql',service.editData);

router.delete('/delete_vocational_skills/:mysql/:id',service.deleteDataById);

// JobIntension
//将router暴露
module.exports = router;

