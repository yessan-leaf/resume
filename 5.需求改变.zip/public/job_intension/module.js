(function (angular) {
    // 创建首页模块
    var app = angular.module('personalinfo.job_intension', ['ngRoute']);
    // 路由配置
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        //解决hash值乱码
        $locationProvider.hashPrefix("");
        $routeProvider.when('/job_intension', {
            templateUrl: './job_intension/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'job_intension_listController'
        })
    }]);


    app.controller('job_intension_listController', [
        '$scope', '$http',
        function ($scope, $http) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));
            //注册初始化页面时间
            $scope.initList = function () {
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/show_job_intension/job_intension'
                })
                    .then(function success(res) {
                        $scope.list = res.data;
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                $scope.mark = new MarkBox(600, 400, '添加个人信息', form[0]);
                $scope.mark.init();
                // 清空表单
                $scope.positions = "";
                $scope.compensation = "";
                $scope.workplace = "";
                $scope.jobnature = "";
                $scope.currentstate = "";
                //表单提交事件
                form.find("input").eq(9).unbind("click").on("click", $scope.subAfterWrite);
            };
            //注册提交事件的方法
            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_job_intension/job_intension',
                    data: {
                        name: $scope.positions,
                        age: $scope.compensation,
                        experience: $scope.workplace,
                        email: $scope.jobnature,
                        phone: $scope.currentstate
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //关闭弹窗
                        $scope.mark.close();
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };
            //注册删除事件
/*            $scope.deleteInfo = function (id) {
                $http({
                    method: 'delete',
                    url: 'http://localhost:3000/delete_job_intension/job_intension/' + id
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.initList();
                    }
                });
            };*/
            //注册修改事件
            $scope.editInfo = function (id) {
                // 先根据数据id查询最新的数据
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_job_intension/job_intension/' + id
                }).then(function success(res) {
                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.positions = res.data.positions;
                    $scope.compensation = res.data.compensation;
                    $scope.workplace = res.data.workplace;
                    $scope.jobnature = res.data.jobnature;
                    $scope.currentstate = res.data.currentstate;
                    form.find("input").eq(7).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_job_intension/job_intension',
                        data: {
                            positions: $scope.positions,
                            compensation: $scope.compensation,
                            workplace: $scope.workplace,
                            jobnature: $scope.jobnature,
                            currentstate: $scope.currentstate
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });

                }
            }
        }]);
})(angular);

