

//引入设置路由需要的块

const express = require("express");
const router = express.Router();
const service = require('./service.js');    


// 提供所有的个人信息
router.get('/show_info_list/:mysql',service.showData);

router.post('/add_info_list/:mysql',service.addData);

router.get('/get_info_list/:mysql/:id',service.getDataById);

router.put('/edit_info_list/:mysql',service.editData);

router.delete('/delete_info_list/:mysql/:id',service.deleteDataById);


// 提供所有的个人信息
/*router.get('/show_job_intension_list/:mysql',service.showData);

router.post('/add_job_intension_list/:mysql',service.addData);

router.get('/get_job_intension_list/:mysql/:id',service.getDataById);

router.put('/edit_job_intension_list/:mysql',service.editData);

router.delete('/delete_job_intension_list/:mysql/:id',service.deleteDataById);
*/
//将router暴露
module.exports = router;

