
(function (angular) {
    // 创建首页模块
    var app = angular.module('personalinfo.more_info', ['ngRoute']);
    // 路由配置
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix("");
        $routeProvider.when('/more_info/:id', {
            templateUrl: './more_info/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'more_info_listController'
        })
        .when('/more_info/:id/personal_info', {
            templateUrl: './personal_info/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'personal_info_listController'
        })
        .when('/more_info/:id/job_intension', {
            templateUrl: './job_intension/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'job_intension_listController'
        })
        .when('/more_info/:id/vocational_skills', {
            templateUrl: './vocational_skills/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'vocational_skills_listController'
        })
        .when('/more_info/:id/occupational_history', {
            templateUrl: './occupational_history/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'occupational_history_listController'
        })
        .when('/more_info/:id/project_experience', {
            templateUrl: './project_experience/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'project_experience_listController'
        })
        .when('/more_info/:id/self_assessment', {
            templateUrl: './self_assessment/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'self_assessment_listController'
        })
        .when('/more_info/:id/contact_me', {
            templateUrl: './contact_me/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'contact_me_listController'
        })
    }])


    app.controller('more_info_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();

            //注册修改事件
            $scope.editPersonalInfo = function (id) {
                // 先根据数据id查询最新的数据
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + id
                }).then(function success(res) {
                    //设置ID不可编辑
                    var id = angular.element(document.getElementById('ID')); 
                    id[0].disabled = true;

                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.id = res.data.id;
                    $scope.name = res.data.name;
                    $scope.age = res.data.age;
                    $scope.experience = res.data.experience;
                    $scope.email = res.data.email;
                    $scope.phone = res.data.phone;
                    $scope.website = res.data.website;
                    $scope.address = res.data.address;
                    $scope.positions = res.data.positions;
                    $scope.compensation = res.data.compensation;
                    $scope.workplace = res.data.workplace;
                    $scope.jobnature = res.data.jobnature;
                    $scope.currentstate = res.data.currentstate;
                    form.find("input").eq(14).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/personal_info_list',
                        data: {
                            id: $scope.id,
                            name: $scope.name,
                            age: $scope.age,
                            experience: $scope.experience,
                            email: $scope.email,
                            phone: $scope.phone,
                            website: $scope.website,
                            address: $scope.address,
                            positions: $scope.positions,
                            compensation: $scope.compensation,
                            workplace: $scope.workplace,
                            jobnature: $scope.jobnature,
                            currentstate: $scope.currentstate
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            $scope.mark.close();
                            $scope.initList(); 
                        }else{
                            console.log("提交失败");
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                }
            }
        }]);

    app.controller('personal_info_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info/' + $scope.getId
                })
                    .then(function success(res) {

                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        
                        $scope.dataList = $scope.todoss;
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.name = "";
                $scope.age = "";
                $scope.yearsOfWorking = "";
                $scope.email = "";
                $scope.phone = "";
                $scope.website = "";
                $scope.address = "";
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id" : $scope.getId || '未填写',
                            "name": $scope.name || "未填写",
                            "age": $scope.age || "未填写",
                            "yearsOfWorking": $scope.yearsOfWorking || "未填写",
                            "email": $scope.email || "未填写",
                            "phone": $scope.phone || "未填写",
                            "website": $scope.website || "未填写",
                            "address": $scope.address || "未填写"
                        }
                $scope.dataList.push($scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/personal_info',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "name": $scope.name || "未填写",
                                    "age": $scope.age || "未填写",
                                    "yearsOfWorking": $scope.yearsOfWorking || "未填写",
                                    "email": $scope.email || "未填写",
                                    "phone": $scope.phone || "未填写",
                                    "website": $scope.website || "未填写",
                                    "address": $scope.address || "未填写"
                                }];
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/personal_info',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/personal_info',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }
            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.name = $scope.dataList[num].name;
                $scope.age = $scope.dataList[num].age;
                $scope.yearsOfWorking = $scope.dataList[num].yearsOfWorking;
                $scope.email = $scope.dataList[num].email;
                $scope.phone = $scope.dataList[num].phone;
                $scope.website = $scope.dataList[num].website;
                $scope.address = $scope.dataList[num].address;
                btn.unbind("click").on("click",$scope.subAfterChange);
            }

            $scope.subAfterChange = function () {

                $scope.next = {
                            "id":$scope.id,
                            "name": $scope.name || "未填写",
                            "age": $scope.age || "未填写",
                            "yearsOfWorking": $scope.yearsOfWorking || "未填写",
                            "email": $scope.email || "未填写",
                            "phone": $scope.phone || "未填写",
                            "website": $scope.website || "未填写",
                            "address": $scope.address || "未填写"//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/personal_info',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);

    app.controller('job_intension_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/job_intension/' + $scope.getId
                })
                    .then(function success(res) {

                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        
                        $scope.dataList = $scope.todoss;
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.positions = "";
                $scope.compensation = "";
                $scope.workplace = "";
                $scope.jobnature = "";
                $scope.currentstate = "";
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            id : $scope.getId || '未填写',
                            positions: $scope.positions || '未填写',
                            compensation: $scope.compensation || '未填写',
                            workplace: $scope.workplace || '未填写',
                            jobnature: $scope.jobnature || '未填写',
                            currentstate: $scope.currentstate || '未填写'
                        }
                $scope.dataList.push($scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/job_intension',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    positions: $scope.positions || '未填写',
                                    compensation: $scope.compensation || '未填写',
                                    workplace: $scope.workplace || '未填写',
                                    jobnature: $scope.jobnature || '未填写',
                                    currentstate: $scope.currentstate || '未填写'
                                }];
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/job_intension',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/job_intension/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/job_intension',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }
            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.positions = $scope.dataList[num].positions;
                $scope.compensation = $scope.dataList[num].compensation;
                $scope.workplace = $scope.dataList[num].workplace;
                $scope.jobnature = $scope.dataList[num].jobnature;
                $scope.currentstate = $scope.dataList[num].currentstate;
                btn.unbind("click").on("click",$scope.subAfterChange);
            }

            $scope.subAfterChange = function () {

                $scope.next = {
                            "id":$scope.id,
                            "positions": $scope.positions || "未填写",
                            "compensation": $scope.compensation || "未填写",
                            "workplace": $scope.workplace || "未填写",
                            "jobnature": $scope.jobnature || "未填写",
                            "currentstate": $scope.currentstate || "未填写",//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/job_intension',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);

    app.controller('vocational_skills_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/vocational_skills/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.todos =  JSON.parse(res.data.lists).dataList;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            $scope.subAfterEdit = function () {
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: $scope.lists || [],
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }


            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify({id:$scope.getId,dataList:[{"id":1,"name":"未填写","completed":false,"$$hashKey":"object:3"}]})
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
                };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/vocational_skills/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
                }

            $scope.isHasId();


            //app.controller('todosController', ['$scope', function($scope){
            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }
              //}]);
                $scope.subAfterEdit = function () {
                    //{id:1,data:[{},{},{}]}
                    //var data1 = JSON.stringify($scope.todos);
                    var data = JSON.stringify({id:$scope.getId,dataList:$scope.todos});
                    console.log($scope.todos);
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/vocational_skills',
                        data: {
                            id : $scope.getId,
                            lists: data || JSON.stringify({id:$scope.getId,dataList:[]}),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }
        }]);

    app.controller('occupational_history_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/occupational_history/' + $scope.getId
                })
                    .then(function success(res) {

                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        
                        $scope.dataList = $scope.todoss;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.time = "";
                $scope.comName = "";
                $scope.section = "";
                $scope.position = "";
                $scope.description = "";
                $scope.todos = [];
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id":$scope.getId,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.push($scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/occupational_history',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "time": $scope.time || "未填写",
                                    "comName": $scope.comName || "未填写",
                                    "section": $scope.section || "未填写",
                                    "position": $scope.position || "未填写",
                                    "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                                }];
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/occupational_history',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/occupational_history/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.todos = [];
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                  console.log($scope.todos);
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }


                $scope.subAfterEdit = function () {
                    $scope.next = {
                                "id":Math.random(),
                                "time": $scope.time || "未填写",
                                "comName": $scope.comName || "未填写",
                                "section": $scope.section || "未填写",
                                "position": $scope.position || "未填写",
                                "description": $scope.todos || [{"id":1,"name":"未填写","completed":false}]//,"$$hashKey":"object:3"
                            };

                    $scope.dataList.push($scope.next);
                   $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/occupational_history',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                            //lists: JSON.stringify($scope.dataList),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/occupational_history',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }

            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                $scope.num = num;
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.time = $scope.dataList[num].time;
                $scope.comName = $scope.dataList[num].comName;
                $scope.section = $scope.dataList[num].section;
                $scope.position = $scope.dataList[num].position;
                $scope.description = $scope.dataList[num].description;
                btn.unbind("click").on("click",$scope.subAfterChange);
                $scope.todos = $scope.description;
            }

            $scope.subAfterChange = function () {
                $scope.next = {
                            "id":$scope.id,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/occupational_history',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);
    
    app.controller('project_experience_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.isHasId();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                });
            };
            //执行初始化页面时间
            $scope.initList();

            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/project_experience/' + $scope.getId
                })
                    .then(function success(res) {
                        if(!res.data.lists){
                            $scope.todoss = {};
                        }else{
                            $scope.todoss =  JSON.parse(res.data.lists).dataList;
                        }
                        
                        $scope.dataList = $scope.todoss;
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册添加个人信息事件
            var btn = angular.element(document.getElementById('btn'));
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();

                $scope.time = "";
                $scope.comName = "";
                $scope.section = "";
                $scope.position = "";
                $scope.description = "";
                $scope.todos = [];
                //表单提交事件
                btn.unbind("click").on("click", $scope.subAfterEdit);
            };

            //注册修改后的提交事件
            $scope.subAfterEdit = function () {
                $scope.next = {
                            "id":$scope.getId,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.unshift($scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/project_experience',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }

            $scope.subAfterWrite = function () {
                $scope.dataList = [{
                                    "id":Math.random(),
                                    "time": $scope.time || "未填写",
                                    "comName": $scope.comName || "未填写",
                                    "section": $scope.section || "未填写",
                                    "position": $scope.position || "未填写",
                                    "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                                }];
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/project_experience',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                            })
                    },
                            
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/project_experience/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
            }

            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.todos = [];
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }


                $scope.subAfterEdit = function () {
                    $scope.next = {
                                "id":Math.random(),
                                "time": $scope.time || "未填写",
                                "comName": $scope.comName || "未填写",
                                "section": $scope.section || "未填写",
                                "position": $scope.position || "未填写",
                                "description": $scope.todos || [{"id":1,"name":"未填写","completed":false}]//,"$$hashKey":"object:3"
                            };

                    $scope.dataList.unshift($scope.next);
                   $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/project_experience',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                            //lists: JSON.stringify($scope.dataList),
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
            }

            //删除一组
            $scope.deleteInfo = function(index){
                if(confirm("确定要清除数据吗？")){
                    $scope.dataList.splice(index,1);
                }
                $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/project_experience',
                        data: {
                            id : $scope.getId,
                            lists: JSON.stringify(
                                {id:$scope.getId,
                                    dataList: $scope.dataList
                                })
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            //$scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                });
            }

            //修改一组
            $scope.changeInfo = function(num){
                //设置弹窗
                $scope.num = num;
                var form = angular.element(document.getElementById('form')); 
                $scope.mark = new MarkBox(600, 600, '添加个人信息', form[0]);
                $scope.mark.init();
                // 对表单提交按钮重新绑定单击事件
                $scope.id = $scope.dataList[num].id;
                $scope.time = $scope.dataList[num].time;
                $scope.comName = $scope.dataList[num].comName;
                $scope.section = $scope.dataList[num].section;
                $scope.position = $scope.dataList[num].position;
                $scope.description = $scope.dataList[num].description;
                btn.unbind("click").on("click",$scope.subAfterChange);
                $scope.todos = $scope.description;
            }

            $scope.subAfterChange = function () {
                $scope.next = {
                            "id":$scope.id,
                            "time": $scope.time || "未填写",
                            "comName": $scope.comName || "未填写",
                            "section": $scope.section || "未填写",
                            "position": $scope.position || "未填写",
                            "description": $scope.todos || [{"id":1,"name":"未填写","completed":false,$$hashKey:"object:9"}]//,"$$hashKey":"object:3"
                        }
                $scope.dataList.splice($scope.num,1,$scope.next);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/project_experience',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify(
                            {id:$scope.getId,
                                dataList: $scope.dataList
                        })
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.mark.close();
                        $scope.initList(); 
                    }else{
                        console.log("提交失败");
                    }
                }, function error(res) {
                    console.log(res);
                });
            }
        }]);
    
    app.controller('self_assessment_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/self_assessment/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.todos =  JSON.parse(res.data.lists).dataList;
                        console.log($scope.todos);
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            $scope.subAfterEdit = function () {
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: $scope.lists || [],
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }


            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify({id:$scope.getId,dataList:[{"id":1,"name":"未填写","completed":false,"$$hashKey":"object:3"}]})
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
                };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/self_assessment/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
                }

            $scope.isHasId();

            //app.controller('todosController', ['$scope', function($scope){
            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                // 功能2.添加任务
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){
                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }
              //}]);

            $scope.subAfterEdit = function () {
                //{id:1,data:[{},{},{}]}
                //var data1 = JSON.stringify($scope.todos);
                var data = JSON.stringify({id:$scope.getId,dataList:$scope.todos});
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: data || JSON.stringify({id:$scope.getId,dataList:[]}),
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }
          }
        }]);
    
    app.controller('contact_me_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
        }]);


})(angular);

