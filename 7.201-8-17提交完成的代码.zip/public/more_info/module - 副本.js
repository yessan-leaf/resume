
(function (angular) {
    // 创建首页模块
    var app = angular.module('personalinfo.more_info', ['ngRoute']);
    // 路由配置
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix("");
        $routeProvider.when('/more_info/:id', {
            templateUrl: './more_info/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'more_info_listController'
        })
    }])


    app.controller('more_info_listController', [
        '$scope', '$http',
        function ($scope, $http) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));
            //注册初始化页面时间
            $scope.initList = function () {
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/show_personal_info_list/personal_info_list'
                })
                    .then(function success(res) {
                        $scope.list = res.data;
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                $scope.mark = new MarkBox(600, 400, '添加个人信息', form[0]);
                $scope.mark.init();
                var id = angular.element(document.getElementById('ID')); 
                id[0].disabled = false; 
                // 清空表单
                $scope.id = "";
                $scope.name = "";
                $scope.age = "";
                $scope.experience = "";
                $scope.email = "";
                $scope.phone = "";
                $scope.website = "";
                $scope.address = "";
                $scope.positions = "";
                $scope.compensation = "";
                $scope.workplace = "";
                $scope.jobnature = "";
                $scope.currentstate = "";
                //表单提交事件
                console.log(form.find("input").eq(14));
                form.find("input").eq(14).unbind("click").on("click", $scope.subAfterWrite);
            };
            //注册提交事件的方法
            $scope.subAfterWrite = function () {
                for (var i = 0; i < $scope.list.length; i++) {
                    if($scope.list[i].id == $scope.id){
                        $scope.error = "ID已经存在";
                        return;
                    };
                }

                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_personal_info_list/personal_info_list',
                    data: {
                        id: $scope.id,
                        name: $scope.name,
                        age: $scope.age,
                        experience: $scope.experience,
                        email: $scope.email,
                        phone: $scope.phone,
                        website: $scope.website,
                        address: $scope.address,
                        positions: $scope.positions,
                        compensation: $scope.compensation,
                        workplace: $scope.workplace,
                        jobnature: $scope.jobnature,
                        currentstate: $scope.currentstate
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //关闭弹窗
                        $scope.mark.close();
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };


            //注册删除事件
            $scope.deletePersonalInfo = function (id) {
                $http({
                    method: 'delete',
                    url: 'http://localhost:3000/delete_personal_info_list/personal_info_list/' + id
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.initList();
                    }
                });
            };




            //注册修改事件
            $scope.editPersonalInfo = function (id) {
                // 先根据数据id查询最新的数据
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_personal_info_list/personal_info_list/' + id
                }).then(function success(res) {
                    //设置ID不可编辑
                    var id = angular.element(document.getElementById('ID')); 
                    id[0].disabled = true;

                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.id = res.data.id;
                    $scope.name = res.data.name;
                    $scope.age = res.data.age;
                    $scope.experience = res.data.experience;
                    $scope.email = res.data.email;
                    $scope.phone = res.data.phone;
                    $scope.website = res.data.website;
                    $scope.address = res.data.address;
                    $scope.positions = res.data.positions;
                    $scope.compensation = res.data.compensation;
                    $scope.workplace = res.data.workplace;
                    $scope.jobnature = res.data.jobnature;
                    $scope.currentstate = res.data.currentstate;
                    form.find("input").eq(14).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_personal_info_list/personal_info_list',
                        data: {
                            id: $scope.id,
                            name: $scope.name,
                            age: $scope.age,
                            experience: $scope.experience,
                            email: $scope.email,
                            phone: $scope.phone,
                            website: $scope.website,
                            address: $scope.address,
                            positions: $scope.positions,
                            compensation: $scope.compensation,
                            workplace: $scope.workplace,
                            jobnature: $scope.jobnature,
                            currentstate: $scope.currentstate
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            $scope.mark.close();
                            $scope.initList(); 
                        }else{
                            console.log("提交失败");
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                }
            }
        }]);
})(angular);

