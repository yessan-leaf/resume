
(function (angular) {
    // 创建首页模块
    var app = angular.module('personalinfo.more_info', ['ngRoute']);
    // 路由配置
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix("");
        $routeProvider.when('/more_info/:id', {
            templateUrl: './more_info/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'more_info_listController'
        })
        .when('/more_info/:id/personal_info', {
            templateUrl: './personal_info/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'personal_info_listController'
        })
        .when('/more_info/:id/job_intension', {
            templateUrl: './job_intension/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'job_intension_listController'
        })
        .when('/more_info/:id/vocational_skills', {
            templateUrl: './vocational_skills/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'vocational_skills_listController'
        })
        .when('/more_info/:id/occupational_history', {
            templateUrl: './occupational_history/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'occupational_history_listController'
        })
        .when('/more_info/:id/project_experience', {
            templateUrl: './project_experience/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'project_experience_listController'
        })
        .when('/more_info/:id/self_assessment', {
            templateUrl: './self_assessment/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'self_assessment_listController'
        })
        .when('/more_info/:id/contact_me', {
            templateUrl: './contact_me/view.html',//注意：路径是从主模块所在路径开始计算的
            controller: 'contact_me_listController'
        })
    }])


    app.controller('more_info_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();

            //注册修改事件
            $scope.editPersonalInfo = function (id) {
                // 先根据数据id查询最新的数据
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + id
                }).then(function success(res) {
                    //设置ID不可编辑
                    var id = angular.element(document.getElementById('ID')); 
                    id[0].disabled = true;

                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.id = res.data.id;
                    $scope.name = res.data.name;
                    $scope.age = res.data.age;
                    $scope.experience = res.data.experience;
                    $scope.email = res.data.email;
                    $scope.phone = res.data.phone;
                    $scope.website = res.data.website;
                    $scope.address = res.data.address;
                    $scope.positions = res.data.positions;
                    $scope.compensation = res.data.compensation;
                    $scope.workplace = res.data.workplace;
                    $scope.jobnature = res.data.jobnature;
                    $scope.currentstate = res.data.currentstate;
                    form.find("input").eq(14).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/personal_info_list',
                        data: {
                            id: $scope.id,
                            name: $scope.name,
                            age: $scope.age,
                            experience: $scope.experience,
                            email: $scope.email,
                            phone: $scope.phone,
                            website: $scope.website,
                            address: $scope.address,
                            positions: $scope.positions,
                            compensation: $scope.compensation,
                            workplace: $scope.workplace,
                            jobnature: $scope.jobnature,
                            currentstate: $scope.currentstate
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            $scope.mark.close();
                            $scope.initList(); 
                        }else{
                            console.log("提交失败");
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                }
            }
        }]);

    app.controller('personal_info_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
        }]);

    app.controller('job_intension_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/job_intension/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.positions = res.data.positions || '未填写';
                        $scope.compensation = res.data.compensation || '未填写';
                        $scope.workplace = res.data.workplace || '未填写';
                        $scope.jobnature = res.data.jobnature || '未填写';
                        $scope.currentstate = res.data.currentstate || '未填写';
                    }, function error(res) {
                        console.log(res);
                    });
            };

            //注册提交事件的方法
            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/job_intension',
                    data: {
                        id : $scope.getId || '未填写',
                        positions: $scope.positions || '未填写',
                        compensation: $scope.compensation || '未填写',
                        workplace: $scope.workplace || '未填写',
                        jobnature: $scope.jobnature || '未填写',
                        currentstate: $scope.currentstate || '未填写'
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
                };
            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/job_intension/' + $scope.getId
                }).then(function success(res){
                        console.log(res);
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
                }

            $scope.isHasId();

            //注册修改事件
            $scope.editInfo = function () {
                // 先根据数据id查询最新的数据
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/job_intension/' + $scope.getId
                }).then(function success(res) {
                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.positions = res.data.positions || '未填写';
                    $scope.compensation = res.data.compensation || '未填写';
                    $scope.workplace = res.data.workplace || '未填写';
                    $scope.jobnature = res.data.jobnature || '未填写';
                    $scope.currentstate = res.data.currentstate || '未填写';
                    form.find("input").eq(7).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/job_intension',
                        data: {
                            id : $scope.getId || '未填写',
                            positions: $scope.positions || '未填写',
                            compensation: $scope.compensation || '未填写',
                            workplace: $scope.workplace || '未填写',
                            jobnature: $scope.jobnature || '未填写',
                            currentstate: $scope.currentstate || '未填写'
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            console.log("保存成功！");
                            $scope.mark.close();
                            $scope.initList();
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                    }
                }
        }]);

    app.controller('vocational_skills_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/vocational_skills/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.todos =  JSON.parse(res.data.lists).dataList;
                        console.log($scope.todos);
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            $scope.subAfterEdit = function () {
                //console.log($scope.getId);
                console.log($scope.lists);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: $scope.lists || [],
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }


            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify({id:$scope.getId,dataList:[{"id":1,"name":"未填写","completed":false,"$$hashKey":"object:3"}]})
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
                };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/vocational_skills/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
                }

            $scope.isHasId();


            //app.controller('todosController', ['$scope', function($scope){
            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                /*$scope.todos = [
                {id:1,name:'吃饭',completed:true},
                {id:2,name:'睡觉',completed:true},
                {id:3,name:'打豆豆',completed:false},
                {id:4,name:'学习',completed:true},
                {id:5,name:'喝水',completed:false},
                ]*/
                // 功能2.添加任务
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                  console.log($scope.todos);
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }
              //}]);

            $scope.subAfterEdit = function () {
                //{id:1,data:[{},{},{}]}
                //var data1 = JSON.stringify($scope.todos);
                var data = JSON.stringify({id:$scope.getId,dataList:$scope.todos});
                console.log($scope.todos);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/vocational_skills',
                    data: {
                        id : $scope.getId,
                        lists: data || JSON.stringify({id:$scope.getId,dataList:[]}),
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }

          }
        }]);
//occupational_history的数据库形式：{"id":"1","dataList":'[{"id":1,"time":"未填写","comName":false,"section":"3","description":"[{"id":1,"name":"熟悉Html5、CSS3，JavaScript技术。","completed":false,"$$hashKey":"object:3"}]"}]'}

    /*$scope.id = "";
    $scope.time = "";
    $scope.comName = "";
    $scope.section = "";
    $scope.position = "";
    $scope.description = "";*/
    var data = {
        "id":"1",
        "dataList":'[{"id":1,
                        "time":"未填写",
                        "comName":false,
                        "section":"3",
                        "description":'[{"id":1,"name":"熟悉Html5、CSS3，JavaScript技术。","completed":false,"$$hashKey":"object:3"}]'}]'};
    

    app.controller('occupational_history_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.addPersonalInfo = function () {
                //初始化弹窗
                $scope.mark = new MarkBox(600, 400, '添加个人信息', form[0]);
                $scope.mark.init();
                /*var id = angular.element(document.getElementById('ID')); 
                id[0].disabled = false; */
                // 清空表单
                $scope.id = "";
                $scope.time = "";
                $scope.comName = "";
                $scope.section = "";
                $scope.position = "";
                $scope.description = "";
                //表单提交事件
                console.log(form.find("input").eq(14));
                form.find("input").eq(14).unbind("click").on("click", $scope.subAfterWrite);
            };
            //注册提交事件的方法
            $scope.subAfterWrite = function () {
                for (var i = 0; i < $scope.list.length; i++) {
                    if($scope.list[i].id == $scope.id){
                        $scope.error = "ID已经存在";
                        return;
                    };
                }

                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/occupational_history',
                    data: {
                        id: $scope.id,
                        time: $scope.time,
                        comName: $scope.comName,
                        section: $scope.section,
                        position: $scope.position,
                        description: $scope.description
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //关闭弹窗
                        $scope.mark.close();
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
            };

            //注册删除事件
            $scope.deletePersonalInfo = function (id) {
                $http({
                    method: 'delete',
                    url: 'http://localhost:3000/delete_info_list/occupational_history/' + id
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        $scope.initList();
                    }
                });
            };

            //注册修改事件
            $scope.editPersonalInfo = function (id) {
                // 先根据数据id查询最新的数据
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/occupational_history/' + id
                }).then(function success(res) {
                    //设置ID不可编辑
                    var id = angular.element(document.getElementById('ID')); 
                    id[0].disabled = true;

                    //设置弹窗
                    $scope.mark = new MarkBox(600, 400, '编辑个人信息', form[0]);
                    $scope.mark.init();
                    // 对表单提交按钮重新绑定单击事件
                    $scope.id = res.data.id;
                    $scope.time = res.data.time;
                    $scope.comName = res.data.comName;
                    $scope.section = res.data.section;
                    $scope.position = res.data.position;
                    $scope.description = res.data.description;
                    form.find("input").eq(14).unbind("click").on("click", $scope.subAfterEdit);//.on("destroy", $scope.subAfterWrite)

                });
                //注册修改后的提交事件
                $scope.subAfterEdit = function () {
                    $http({
                        method: 'put',
                        url: 'http://localhost:3000/edit_info_list/occupational_history',
                        data: {
                            id: $scope.id,
                            time: $scope.time,
                            comName: $scope.comName,
                            section: $scope.section,
                            position: $scope.position,
                            description: $scope.description
                        },
                        //设置请求头
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        //设置form data 提交格式
                        transformRequest: function (data) {
                            var str = [];
                            for (var key in data) {
                                str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                            }
                            return str.join("&");
                        }
                    }).then(function success(res) {
                        if (res.data.flag == '1') {
                            $scope.mark.close();
                            $scope.initList(); 
                        }else{
                            console.log("提交失败");
                        }
                    }, function error(res) {
                        console.log(res);
                    });
                }
            }
        }]);
    
    app.controller('project_experience_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
        }]);
    
    app.controller('self_assessment_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
            //注册添加个人信息事件
            $scope.formInitList = function(){
                //注册初始化页面时间
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/self_assessment/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.todos =  JSON.parse(res.data.lists).dataList;
                        console.log($scope.todos);
                        $scope.initData();
                    }, function error(res) {
                        console.log(res);
                    });
            };

            $scope.subAfterEdit = function () {
                //console.log($scope.getId);
                console.log($scope.lists);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: $scope.lists || [],
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }


            $scope.subAfterWrite = function () {
                $http({
                    method: 'post',
                    url: 'http://localhost:3000/add_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: JSON.stringify({id:$scope.getId,dataList:[{"id":1,"name":"未填写","completed":false,"$$hashKey":"object:3"}]})
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data的数据提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        //初始化页面
                        $scope.initList();
                    }
                }, function error(data) {
                    console.log(data);
                });
                };

            $scope.isHasId = function(){
                $http({
                    type: 'GET',
                    url: 'http://localhost:3000/get_info_list/self_assessment/' + $scope.getId
                }).then(function success(res){
                    if(res.data.id){
                        return;
                    }
                    $scope.subAfterWrite();
                });
                }

            $scope.isHasId();


            //app.controller('todosController', ['$scope', function($scope){
            $scope.initData = function(){  
                // 功能1.任务的展示(ng-repeat)
                // 假设已经得到数据
                /*$scope.todos = [
                {id:1,name:'吃饭',completed:true},
                {id:2,name:'睡觉',completed:true},
                {id:3,name:'打豆豆',completed:false},
                {id:4,name:'学习',completed:true},
                {id:5,name:'喝水',completed:false},
                ]*/
                // 功能2.添加任务
                $scope.newTodo=''  // ng-model
                $scope.add = function(){
                  // 判断newTodo是否为空，为空则不添加任务
                  if(!$scope.newTodo){
                    return
                  }

                  // 把新任务添加到$scope.todos中去
                  $scope.todos.push({
                    id:Math.random(),
                    name:$scope.newTodo,
                    completed:false
                  })
                  // 置空
                  $scope.newTodo=''
                  console.log($scope.todos);
                }

                // 功能3.删除任务
                $scope.remove = function(id){
                  // 根据id到数组$scope.todos中查找相应元素，并删除
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(item.id === id){
                      $scope.todos.splice(i,1) // 删除数据
                      return
                    }
                  }
                }

                // 功能4：修改任务内容 
                $scope.isEditingId = -1
                $scope.edit = function(id){
                  $scope.isEditingId = id
                }

                // 只是改变也文本框的编辑状态
                $scope.save = function(){
                  $scope.isEditingId = -1
                }

                // 功能5.修改任务状态

                // 功能6.批量切换任务状态
                $scope.selectAll = false
                $scope.toggleAll = function(){
                  // 让$scope.todos中所有数据的completed值等于$scope.selectAll
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    item.completed = $scope.selectAll
                  }
                }

                // 功能7.显示未完成任务数
                $scope.getActive = function(){
                  var count = 0
                  // 遍历$scope.todos, 找到所有completed属性值为false的数据
                  for (var i = 0; i < $scope.todos.length; i++) {
                    var item = $scope.todos[i]
                    if(!item.completed){
                      count++
                    }
                  }
                  return count
                }

                // 功能8.清除所有已完成任务
                $scope.clearAll = function(){

                  for (var i = $scope.todos.length - 1; i >= 0; i--) {
                    // true(0),false(1),false(2)
                    var item = $scope.todos[i]
                    if(item.completed){
                      $scope.todos.splice(i,1)
                    }
                  }
                }
              //}]);

            $scope.subAfterEdit = function () {
                //{id:1,data:[{},{},{}]}
                //var data1 = JSON.stringify($scope.todos);
                var data = JSON.stringify({id:$scope.getId,dataList:$scope.todos});
                console.log($scope.todos);
                $http({
                    method: 'put',
                    url: 'http://localhost:3000/edit_info_list/self_assessment',
                    data: {
                        id : $scope.getId,
                        lists: data || JSON.stringify({id:$scope.getId,dataList:[]}),
                    },
                    //设置请求头
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    //设置form data 提交格式
                    transformRequest: function (data) {
                        var str = [];
                        for (var key in data) {
                            str.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
                        }
                        return str.join("&");
                    }
                }).then(function success(res) {
                    if (res.data.flag == '1') {
                        console.log("保存成功！");
                        $scope.initList();
                    }
                }, function error(res) {
                    console.log(res);
                });
                }

          }
        }]);
    
    app.controller('contact_me_listController', [
        '$scope', '$http','$window',
        function ($scope, $http,$window) {
            //后去表单元素
            var form = angular.element(document.getElementById('personal_info_form'));  
            $scope.initList = function () {
                $scope.getId=$window.location.hash.split('/')[2];
  
                $scope.list = {};
                $http({
                    method: 'GET',
                    url: 'http://localhost:3000/get_info_list/personal_info_list/' + $scope.getId
                })
                    .then(function success(res) {
                        $scope.id = res.data.id;
                        $scope.name = res.data.name;
                        // $scope.subAfterWrite();
                        // $scope.formInitList();
                    }, function error(res) {
                        console.log(res);
                    });
            };
            //执行初始化页面时间
            $scope.initList();
        }]);


})(angular);

