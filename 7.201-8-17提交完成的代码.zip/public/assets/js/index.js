
$(function(){
    initList();
    addPersonalInfo();
});


function initList(){
        $.ajax({
            type : 'get',
            url : 'http://localhost:3000/show_personal_info',
            dataType : 'json',
            success : function(data){
                // 渲染数据列表
                var html = template('indexTpl',{list : data});
                $('#dataList').html(html);
                // 必须在渲染完成内容之后才可以操作DOM标签

                $('#dataList').find('tr').each(function(index,element){
                    var td = $(element).find('td:eq(8)');
                    var id = $(element).find('td:eq(0)').text();
                    // 绑定编辑图书的单击事件
                    td.find('a:eq(0)').click(function(){
                        editPersonalInfo(id);
                    });
                    td.find('a:eq(1)').click(function(){
                        deletePersonalInfo(id);
                    });
                    
                    addPersonalInfo();
                    
                    var form = $('#personal_info_form');
                    form.get(0).reset();
                    form.find('input[type=hidden]').val('');
                });
            }
        });
    }

function addPersonalInfo(){
    $('#add_personal_info').click(function(){
        var form = $('#personal_info_form');
        // 实例化弹窗对象
        var mark = new MarkBox(600,400,'添加图书',form.get(0));
        mark.init();
        form.find('input[type=button]').unbind('click').click(function(){
            $.ajax({
                type : 'post',
                url : 'http://localhost:3000/add_personal_info',
                data : form.serialize(),
                dataType : 'json',
                success : function(data){
                    if(data.flag == '1'){
                        mark.close();
                        initList();
                    }
                }
            });
        });
    });
}


function deletePersonalInfo(id){
    $.ajax({
        type : 'delete',
        url : 'http://localhost:3000/delete_personal_info/' + id,
        dataType : 'json',
        success : function(data){
            // 删除图书信息之后重新渲染数据列表
            if(data.flag == '1'){
                initList();
            }
        }
    });
}

function editPersonalInfo(id){
    var form = $('#personal_info_form');
    // 先根据数据id查询最新的数据
    $.ajax({
        type : 'get',
        url : 'http://localhost:3000/get_personal_info/' + id,
        dataType : 'json',
        success : function(data){
            // 初始化弹窗
            var mark = new MarkBox(600,400,'编辑图书',form.get(0));
            mark.init();
            // 填充表单数据
            form.find('input[name=id]').val(data.id);
            form.find('input[name=name]').val(data.name);
            form.find('input[name=age]').val(data.age);
            form.find('input[name=experience]').val(data.experience);
            form.find('input[name=email]').val(data.email);
            form.find('input[name=phone]').val(data.phone);
            form.find('input[name=website]').val(data.website);
            form.find('input[name=address]').val(data.address);
            // 对表单提交按钮重新绑定单击事件
            form.find('input[type=button]').unbind('click').click(function(){
                // 编辑完成数据之后重新提交表单
                $.ajax({
                    type : 'put',
                    url : 'http://localhost:3000/edit_personal_info',
                    data : form.serialize(),
                    dataType : 'json',
                    success : function(data){
                        if(data.flag == '1'){
                            // 隐藏弹窗
                            mark.close();
                            // 重新渲染数据列表
                            initList();
                        }
                    }
                });
            });
        }
    });
}