

//引入设置路由需要的块

const express = require("express");
const router = express.Router();
const service = require('./service.js');    

// 提供所有的个人信息
router.get('/show_personal_info',service.showPersonalInfo);

router.post('/add_personal_info',service.addPersonalInfo);

router.get('/get_personal_info/:id',service.getPersonalInfoById);

router.put('/edit_personal_info',service.editPersonalInfo);

router.delete('/delete_personal_info/:id',service.deletePersonalInfo);

// 求职意向
router.get('/show_personal_info',service.showPersonalInfo);

router.post('/add_personal_info',service.addPersonalInfo);

router.get('/get_personal_info/:id',service.getPersonalInfoById);

router.put('/edit_personal_info',service.editPersonalInfo);

router.delete('/delete_personal_info/:id',service.deletePersonalInfo);


//将router暴露
module.exports = router;

