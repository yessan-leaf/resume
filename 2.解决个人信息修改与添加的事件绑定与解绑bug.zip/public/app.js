(function (angular) {
    // 1.创建一个主模块
    var app = angular.module('personalinfo', [
        'personalinfo.personal_info',// 先引入就会优先匹配相应的路由规则
        'personalinfo.personal_info',
        'personalinfo.personal_info',
        'personalinfo.personal_info',
    ]);
    app.controller('mainController', ['$scope', '$location'
        , function ($scope, $location) {
            $scope.query = '';
            $scope.search = function () {
                // 改变的url中的锚点，不用再去发请求.
                $locationProvider.hashPrefix(strBangName);
                $location.url('/search/?q=' + $scope.query);
            }
        }]);
})(angular);