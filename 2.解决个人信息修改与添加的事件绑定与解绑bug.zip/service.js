
//设置获取数据的方法
const db = require('./db.js');

exports.showPersonalInfo = (req,res) => {
    let sql = 'select * from personal_info';
    db.base(sql,null,(result)=>{
        res.json(result);
    });
};


exports.addPersonalInfo = (req,res) => {
    let data = req.body;
    let sql = 'insert into personal_info set ?';
    db.base(sql,data,(result)=>{
        if(result.affectedRows == 1){
            res.json({flag : 1});
        }else{
            res.json({flag : 2});
        }  
    });
};
exports.getPersonalInfoById = (req,res) => {
    let id = req.params.id;
    let sql = 'select * from personal_info where id=?'
    let data = [id];
    db.base(sql,data,(result)=>{
        res.json(result[0]);
    })
};

exports.editPersonalInfo = (req,res) => {
    let info = req.body;
    console.log(info);
    let sql = 'update personal_info set name=?,age=?,experience=?,email=?,phone=?,website=?,address=? where id=?';
    let data = [info.name,info.age,info.experience,info.email,info.phone,info.website,info.address,info.id];
    
    db.base(sql,data,(result)=>{
        if(result.affectedRows == 1){
            res.json({flag : 1});
        }else{
            res.json({flag : 2});
        }  
    });
};
exports.deletePersonalInfo = (req,res) => {
    let id = req.params.id;
    let sql = 'delete from personal_info where id=?';
    let data = [id];    
    db.base(sql,data,(result)=>{
        if(result.affectedRows == 1){
            res.json({flag : 1});
        }else{
            res.json({flag : 2});
        }  
    });
};
